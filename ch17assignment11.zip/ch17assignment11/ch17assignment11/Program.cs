﻿using System;

namespace ch17assignment11
{
    class Problem11   
    { static void Main(string[] args)
        {
        char ch;
            int i = 1;
            int j = 0; 
            while (i <= 16) { j = i + 64;
                ch = (char)j;
                Console.Write(ch);
                Console.Write(" "); 
                i = i * 2;
            }
        Console.ReadKey();
    }
    }
}
