﻿using System;

namespace ch4practice
{
    class Program
    {
        public static void Main(string[] args)
        {
            var arr = new[] { 10, 11, 100, 101, 110 };
            var a = 51;
            var s = "Python";
            Console.WriteLine(a);
            Console.WriteLine(s);
            Console.WriteLine(arr[2]);
        }
    }
}
