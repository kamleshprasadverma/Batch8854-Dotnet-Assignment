﻿using System;

namespace arrayonee
{
    class Program
    {
       public static void Main(string[] args)
        {
            int[] arr = new int[] { 11, 15, 72, 45, 528 };
            for(int i=0;i<arr.Length;i++)
            {
                Console.WriteLine(arr[i]);
            }
            Console.ReadLine();
        }
    }
}
