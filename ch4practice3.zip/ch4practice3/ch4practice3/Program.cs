﻿using System;

namespace ch4practice3
{
    class one { }
    class two { }
    public class Demo
    {
        public static void test(object obj)
        {
            one x;
            two y;
            if(obj is one )
            {
                Console.WriteLine("class one");
                x = (one)obj;
            }
            else if (obj is two)
            {
                Console.WriteLine("class two");
                y = (two)obj;
            }
            else
            {
                Console.WriteLine("none of the class");
            }
        }
       public static void Main(string[] args)
        {
            one o1 = new one();
            two t1 = new two();
            test(o1);
            test(t1);
            test("str");
            Console.ReadKey();
            Console.WriteLine("Hello World!");
        }
    }
}
