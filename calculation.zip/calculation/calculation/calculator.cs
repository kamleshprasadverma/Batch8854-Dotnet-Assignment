﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculation
{
    public class calculator
    {
        public int addition(int a,int b)
        {
            return a + b;
        }
        public int subtraction( int a,int b)
            {
            return a - b;
        }
        public int division(int a, int b)
        {
            return a / b;
        }
        public int multi(int a, int b)
        {
            return a * b;
        }

    }
}
