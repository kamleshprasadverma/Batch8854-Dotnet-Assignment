﻿using System;

namespace ch4string_class
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "CodesDope";
            string s4 = "codesdope";
            int p = String.Compare(s, s4);
            int q = String.Compare(s, s4, true);
            string w = s.Substring(5);
            string k = s.Substring(5, 2);
            string u = s.Replace("Dope", "Codes");
            string f = s.ToLower();
            string g = s.ToUpper();


            char[] charArray = { 'c', 'o', 'd', 'e', 's', 'D', 'o', 'p', 'e' };
            String s1 = new string(charArray);
            string[] e = { "Co", "de", "sD", "op", "e" };
            string v = string.Concat(e);
            string a = "Codes";
            string b = "Dope";
            int x = String.Compare(a, b);
            int y = String.Compare(b, a);
            string c = a + b;
            string d = string.Concat(a, b);
            a = a + b;
            Console.WriteLine(s);
            Console.WriteLine(s1);
            Console.WriteLine(s[0]);
            Console.WriteLine(s[1]);
            Console.WriteLine(s[2]);
            Console.WriteLine(s[3]);
            Console.WriteLine(s[4]);
            Console.WriteLine(c);
            Console.WriteLine(a);
            Console.WriteLine(s.Length);
            Console.WriteLine(d);
            Console.WriteLine(v);
            Console.WriteLine(x);
            Console.WriteLine(y);
            Console.WriteLine(p);
            Console.WriteLine(q);
            Console.WriteLine(a.Equals(b));
            Console.WriteLine(s.IndexOf('D'));
            Console.WriteLine(s.LastIndexOf('o'));
            Console.WriteLine(u);
            Console.WriteLine(w);
            Console.WriteLine(k);
            Console.WriteLine(f);
            Console.WriteLine(g);


        }
    }
}
