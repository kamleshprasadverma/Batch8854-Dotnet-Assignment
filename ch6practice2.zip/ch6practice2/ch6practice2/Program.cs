﻿using System;

namespace ch6practice2
{
    struct Str
    {
        int a, b;
        public Str(int y, int x)
        {
            a = x;
            b = y;
        }

        public int sum()
        {
            Str obj = new Str();
            Console.WriteLine("Enter a No.");
            a = Int32.Parse(Console.ReadLine());
            b = Int32.Parse(Console.ReadLine());
            return (a + b);
        //   int c = a + b;
          //Console.WriteLine("sum=" + c);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //int a, b;
            Str obj = new Str();
            int c = obj.sum();
            Console.WriteLine("Sum="+c);
        }
    }
}
