﻿using System;

namespace ch17assignment13
{
    class Problem13 
    { static void Main(string[] args)
        {
        char ch;
        int i = 0;
            while (i <= 255) 
            {
                Console.Write(i);
                Console.Write(" ");
                ch = (char)i;
                Console.WriteLine(ch);
                i++;
            }
            Console.ReadKey();
        }
    }
}
