create table Users
( ID int not null,
name varchar(100) ,
title varchar(100),
address varchar(100));

select* from Users;