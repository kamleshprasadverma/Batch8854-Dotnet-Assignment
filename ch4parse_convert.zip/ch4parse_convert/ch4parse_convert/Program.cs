﻿using System;

namespace ch4parse_convert
{
    class Program
    {
        static void Main(string[] args)
        {
            string input1 = "101";
            int input2 = 101;
            string input3 = "Am String";
            string input4 = null;
            string input5 = "855555555555555555555.00052555555555555";
            string input6 = "85555555555555555555500052555555555555";
            bool input00 = false;


            Console.WriteLine("int.Parse:(String to integer) : " + int.Parse(input1));
            Console.WriteLine("int.prase:(integer to integer):" + int.Parse(input2.ToString()));
            //Console.WriteLine("int.Parse:(Converted String to integer):" + int.Parse(input3));
            //.WriteLine(value: "int.Parse:(Converted String to integer) : " + int.Parse(input4));
            Console.WriteLine("int.Prase:" + int.Parse(input5));
            Console.WriteLine("int.Parse:(Long to integer):" + int.Parse(input6));
            Console.WriteLine("Convert.ToInt32:(bool to integer) : " + Convert.ToInt32(input00));
            Console.WriteLine("Convert.ToInt32:(String to integer) : " + Convert.ToInt32(input1));
            Console.WriteLine("Convert.ToInt32:(integer to integer) : " + Convert.ToInt32(input2.ToString()));
            Console.WriteLine("Convert.ToInt32:(String to integer) : " + Convert.ToInt32(input3));
            Console.WriteLine("Convert.ToInt32:(null to integer) : " + Convert.ToInt32(input4));
            Console.WriteLine("Convert.ToInt32: " + Convert.ToInt32(input5));
            Console.WriteLine("Convert.ToInt32:(Long to integer) : " + Convert.ToInt32(input6));

        }
       
    }
}
