﻿using System;

namespace ch4practice6
{
    class NumberManipulation
    {
        public void swap(ref int x,ref int y)
        {

            int temp;
            temp = x;
            x = y;
            y = temp;
        }
    
    
        static void Main(string[] args)
        {
        NumberManipulation n = new NumberManipulation();
        int a = 100;
        int b = 500;
        Console.WriteLine("Before swap, value of a:{0}", a);
        Console.WriteLine("Before swap, value of b:{0}", b);
        n.swap(ref a, ref b);
        Console.WriteLine("After swap swap, value of a:{0}", a);
        Console.WriteLine("After swap, value of b:{0}", b);
        Console.ReadLine();
        }
    }
}
