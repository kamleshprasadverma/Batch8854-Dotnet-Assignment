﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace ch31project1._2
{
    public partial class Form1 : Form
    {
        {
 SqlConnection con = new SqlConnection("Data Source=localhost\SQLEXPRESS;Initial Catalog=master;Integrated Security=True");
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("select * from emp where username = @username and password = @password", con);
           
            cmd.Parameters.AddWithValue("@username", .Text);
            cmd.Parameters.AddWithValue("@password", .Text);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (dt.Rows.Count > 0)
            {
                string str = .Text;
                string pwd = .Text;
                MessageBox.Show("welcome Username :" + str);
            }
            else
            {
                MessageBox.Show("please enter correct Username and password");
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
