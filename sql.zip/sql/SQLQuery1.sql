select * from cust;
create view cust_view
as
select * from cust;

select * from cust_view;


create view cu_view
as
select name,salary from cust;

select * from cu_view;

create table student
(
rollno int not null primary key,
name varchar(40) ,
English int,
physic int ,
chemistory int,
Math int,
total int,
persentage int
);

select * from student ;


create trigger marks
on student alter insert into student
for each row 
set total=English+physic+chemistory+math,persentage=(total /400)*100);

