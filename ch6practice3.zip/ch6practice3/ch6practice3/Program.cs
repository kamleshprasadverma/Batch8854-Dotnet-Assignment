﻿using System;

namespace ch6practice3
{
    struct student
    {
        public String name, last;
    }struct marrks
    {
        public student s;
        public int math, sci;
    }
    class Program
    {
       
        static void Main(string[] args)
        {
            marrks m;
            m.s.name = "kamlesh";
            m.s.last = "verma";
            m.math = 70;
            m.sci = 75;
            Console.WriteLine("Name = " + m.s.name);
            Console.WriteLine("Last Name = " + m.s.last);
            Console.WriteLine("Math Marks = " + m.math);
            Console.WriteLine("Science = " + m.sci);
            Console.WriteLine("Hello World!");
        }
    }
}
