﻿using System;

namespace arrayone
{
    public class Program
    {
       public static void Main(string[] args)
        {
            int[] arr = { 10, 22, 33, 44, 55 };
            int len = arr.Length;
            Console.WriteLine("Length of Array " + len);
            Console.WriteLine(arr[0] + "" + arr[4]);
        }
    }
}
