﻿using System;

namespace ch4practice4
{
    class Demo
    {
        public static void Main()
        {
            object[] obj = new object[4];
            obj[0] = "jack";
            obj[1] = "32";
            obj[2] = "note";
            obj[3] = "55";
            for (int i = 0; i < obj.Length; i++)
            {
                string s = obj[i] as string;
                Console.Write("{0}:", i);
                if (s != null)
                    Console.WriteLine("'" + s + "'");
                else
                    Console.WriteLine("this is not string!");
            }
            Console.ReadKey();
        }
    }
}
