﻿using System;

namespace ch4equal_ref
{
    class program
    {
        public class Class1 : Object
        {
            public void Method1()
            {
                Console.WriteLine("Method 1");
            }
        }
        public class Class2 : Class1
        {
            public void Method()
            {
                Console.WriteLine("Method 2");
            }
        }
        static void Main(string[] args)
        {
            Class1 obj = new Class1();
            Class2 obj2 = new Class2();
            string s1 = "String";
            string s2 = "String";
            Console.WriteLine("Coparision of two object");
            Console.WriteLine(Object.Equals(obj, obj2));
            Console.WriteLine(Object.Equals(s1, s2));
            Console.WriteLine(Object.ReferenceEquals(obj, obj2));
            Console.WriteLine(Object.ReferenceEquals(obj, obj2));
            Console.WriteLine(Object.ReferenceEquals(s1, s2));
            Console.ReadLine();
        }
    }
}
