﻿using System;

namespace ch4get_hash_code
{
    class Program
    {
        class Hashing
        {
            string name;
            public Hashing(string name)
            {
                this.name = name;
            }
            public override int GetHashCode()
            {
                string n = ToString();
                return base.GetHashCode();
            }
        }
        static void Main(string[] args)
        {
            Hashing ob1 = new Hashing("Kamlesh prasad Verma");
            Console.WriteLine(ob1.GetHashCode());
            Console.ReadLine();
        }
    }
}
