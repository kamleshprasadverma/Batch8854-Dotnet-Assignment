﻿using System;

namespace ch6practice
{
    struct str
    {
        int a, b;
        public void get()
        {
            Console.WriteLine("enter a number");
            a = Int32.Parse(Console.ReadLine());
            b = Int32.Parse(Console.ReadLine());
        }
        public void show()
        {
            int c = a + b;
            Console.WriteLine("sum=" + c);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            str obj = new str();
            obj.get();
            obj.show();
            Console.WriteLine("Hello World!");
        }
    }
}
