﻿using System;

namespace ch4practice2
{
    class Demo
    {
        dynamic data = 12;
        public int Method(int a, int b)
        {
            return (a + b) * data;
        }
    }
    class Program
    { 
        static void Main(string[] args)
        {
            Demo Ob = new Demo();
            dynamic value1;
            dynamic value2;
            Console.WriteLine("Enter first value1:");
            value1=Console.ReadLine();
            int a = Convert.ToInt32(value1);
            Console.WriteLine("Enter second Value2:");
            value2=Console.ReadLine();
            int b = Convert.ToInt32(value2);
            
            Console.WriteLine("the out put is "+ Ob.Method(a,b));
            Console.ReadLine();
        }
    }
}
