﻿using System;
using System.Web.UI;
using WcfService1.ServiceReference1;

namespace WcfService1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ServiceClient client = new ServiceClient();

            //ServiceReference.ServiceClient client = new ServiceReference.ServiceClient();
             GridView1.DataSource = client.GetCustomers().CustomersTable;
             GridView1.DataBind();


        }
    }
}