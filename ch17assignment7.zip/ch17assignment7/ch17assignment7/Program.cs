﻿using System;

namespace ch17assignment7
{
    class Problem7     
    { static void Main(string[] args)
        {
         int year;
            string a;
            Console.WriteLine("Enter A Year:");
            year = Convert.ToInt32(Console.ReadLine()); 
            a = year % 4 == 0 ? "Year Is Leap" : "It Is Not A Leap Year:"; 
            Console.WriteLine(a);
            Console.ReadKey();
    }
    }
}
