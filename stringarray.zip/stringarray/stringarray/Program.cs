﻿using System;

namespace stringarray
{
    class Program
    {
       public static void Main(string[] args)
        {
            string[] arr = new string[] { "C++", "JAVA", "C#", "Python", "HTML" };
            foreach(string a in arr)
            {
                Console.WriteLine ( a );
            }
            Console.ReadLine();
        }
    }
}
